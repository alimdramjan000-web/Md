# Connecto

A simple Flutter social-media app prototype for Android and iOS.

## Current prototype
- Home feed
- Stories-style row
- Create post
- Like button
- Search screen
- Activity/notifications screen
- Profile screen
- Bottom navigation
- Simple responsive Material 3 UI

## Run
1. Install Flutter.
2. Extract this project.
3. Open a terminal in the project folder.
4. Run `flutter pub get`
5. Run `flutter run`

## Important
This is the first working UI/prototype. It does not yet have a real online database, real accounts, image upload, or real-time chat. Those features require a backend such as Firebase/Supabase and platform configuration.
