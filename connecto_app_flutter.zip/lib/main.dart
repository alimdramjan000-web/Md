import 'package:flutter/material.dart';

void main() => runApp(const ConnectoApp());

class ConnectoApp extends StatelessWidget {
  const ConnectoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Connecto',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6C35E8)),
        scaffoldBackgroundColor: const Color(0xFFF8F7FB),
      ),
      home: const MainShell(),
    );
  }
}

class Post {
  Post({required this.name, required this.text, required this.likes});
  final String name;
  final String text;
  int likes;
  bool liked = false;
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final posts = <Post>[
    Post(name: 'Sabur Rahman', text: 'Beautiful day! 🌅\nConnect. Share. Inspire.', likes: 124),
    Post(name: 'Samiha Islam', text: 'Coffee time ☕', likes: 76),
  ];

  void addPost(String text) {
    if (text.trim().isEmpty) return;
    setState(() => posts.insert(0, Post(name: 'You', text: text.trim(), likes: 0)));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(posts: posts, onLike: (p) => setState(() {
        p.liked = !p.liked;
        p.likes += p.liked ? 1 : -1;
      })),
      const SearchPage(),
      CreatePage(onPost: addPost),
      const NotificationsPage(),
      const ProfilePage(),
    ];

    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'Post'),
          NavigationDestination(icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'Activity'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class Header extends StatelessWidget {
  const Header({super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
    child: Row(
      children: [
        const Text('Connecto', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: Color(0xFF5B2BD9))),
        const Spacer(),
        IconButton(onPressed: () {}, icon: const Icon(Icons.chat_bubble_outline)),
      ],
    ),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.posts, required this.onLike});
  final List<Post> posts;
  final void Function(Post) onLike;

  @override
  Widget build(BuildContext context) => ListView(
    padding: EdgeInsets.zero,
    children: [
      const Header(),
      SizedBox(
        height: 92,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          children: const [
            Story(name: 'Your story', add: true),
            Story(name: 'Rifat'),
            Story(name: 'Samiha'),
            Story(name: 'Nayeem'),
            Story(name: 'Tanha'),
          ],
        ),
      ),
      const Divider(height: 1),
      ...posts.map((p) => PostCard(post: p, onLike: () => onLike(p))),
    ],
  );
}

class Story extends StatelessWidget {
  const Story({super.key, required this.name, this.add = false});
  final String name;
  final bool add;
  @override
  Widget build(BuildContext context) => Container(
    width: 78,
    margin: const EdgeInsets.only(right: 8),
    child: Column(
      children: [
        Stack(
          children: [
            Container(
              width: 58, height: 58,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFF7B45EA), width: 2.5),
              ),
              child: const CircleAvatar(child: Icon(Icons.person)),
            ),
            if (add) Positioned(right: 0, bottom: 0, child: Container(
              decoration: const BoxDecoration(color: Color(0xFF6C35E8), shape: BoxShape.circle),
              padding: const EdgeInsets.all(3),
              child: const Icon(Icons.add, color: Colors.white, size: 16),
            ))
          ],
        ),
        const SizedBox(height: 5),
        Text(name, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
      ],
    ),
  );
}

class PostCard extends StatelessWidget {
  const PostCard({super.key, required this.post, required this.onLike});
  final Post post;
  final VoidCallback onLike;
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.fromLTRB(10, 10, 10, 2),
    elevation: 0,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    child: Padding(
      padding: const EdgeInsets.all(13),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const CircleAvatar(child: Icon(Icons.person)),
          const SizedBox(width: 10),
          Expanded(child: Text(post.name, style: const TextStyle(fontWeight: FontWeight.bold))),
          const Icon(Icons.more_horiz),
        ]),
        const SizedBox(height: 12),
        Text(post.text, style: const TextStyle(fontSize: 16, height: 1.35)),
        const SizedBox(height: 12),
        Container(
          height: 170,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: const LinearGradient(colors: [Color(0xFFE6DEFF), Color(0xFFF7DDF0)]),
          ),
          child: const Center(child: Icon(Icons.image_outlined, size: 58, color: Color(0xFF6C35E8))),
        ),
        const SizedBox(height: 8),
        Text('${post.likes} likes', style: const TextStyle(color: Colors.grey)),
        const Divider(),
        Row(children: [
          Expanded(child: TextButton.icon(
            onPressed: onLike,
            icon: Icon(post.liked ? Icons.favorite : Icons.favorite_border,
              color: post.liked ? Colors.red : null),
            label: const Text('Like'),
          )),
          const Expanded(child: TextButton.icon(onPressed: null, icon: Icon(Icons.comment_outlined), label: Text('Comment'))),
          const Expanded(child: TextButton.icon(onPressed: null, icon: Icon(Icons.share_outlined), label: Text('Share'))),
        ]),
      ]),
    ),
  );
}

class CreatePage extends StatefulWidget {
  const CreatePage({super.key, required this.onPost});
  final void Function(String) onPost;
  @override State<CreatePage> createState() => _CreatePageState();
}
class _CreatePageState extends State<CreatePage> {
  final controller = TextEditingController();
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(18),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Create Post', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 20),
      const Row(children: [CircleAvatar(child: Icon(Icons.person)), SizedBox(width: 10), Text('You', style: TextStyle(fontWeight: FontWeight.bold))]),
      const SizedBox(height: 20),
      TextField(
        controller: controller,
        maxLines: 7,
        decoration: InputDecoration(
          hintText: "What's on your mind?",
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 14),
      Row(children: [
        OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.photo_outlined), label: const Text('Photo')),
        const SizedBox(width: 8),
        OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.emoji_emotions_outlined), label: const Text('Feeling')),
      ]),
      const Spacer(),
      SizedBox(width: double.infinity, child: FilledButton(
        onPressed: () { widget.onPost(controller.text); controller.clear(); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Post added!'))); },
        child: const Text('Post'),
      )),
    ]),
  );
}

class SearchPage extends StatelessWidget {
  const SearchPage({super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(18),
    child: Column(children: [
      const Align(alignment: Alignment.centerLeft, child: Text('Search', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold))),
      const SizedBox(height: 18),
      TextField(decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Search people and posts', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
    ]),
  );
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: const [
      Text('Activity', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      SizedBox(height: 18),
      ListTile(leading: Icon(Icons.favorite, color: Colors.red), title: Text('Rifat liked your post'), subtitle: Text('2 minutes ago')),
      ListTile(leading: Icon(Icons.person_add), title: Text('Samiha started following you'), subtitle: Text('1 hour ago')),
      ListTile(leading: Icon(Icons.comment), title: Text('Nayeem commented on your post'), subtitle: Text('Yesterday')),
    ],
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const SizedBox(height: 12),
      const Center(child: CircleAvatar(radius: 46, child: Icon(Icons.person, size: 48))),
      const SizedBox(height: 10),
      const Center(child: Text('Your Name', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold))),
      const Center(child: Text('Connect. Share. Inspire.', style: TextStyle(color: Colors.grey))),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: const [
        Stat(number: '12', label: 'Posts'),
        Stat(number: '1.2K', label: 'Followers'),
        Stat(number: '320', label: 'Following'),
      ]),
      const SizedBox(height: 20),
      FilledButton(onPressed: () {}, child: const Text('Edit Profile')),
    ],
  );
}

class Stat extends StatelessWidget {
  const Stat({super.key, required this.number, required this.label});
  final String number, label;
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(number, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
    Text(label, style: const TextStyle(color: Colors.grey)),
  ]);
}
